/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author SalvadorDonesta
 */
public class CaixaDeSom {
    
    public void emitirSom(String sinal){
        System.out.println("Som em reprodução: " + sinal + "\n");
    }
    
}
