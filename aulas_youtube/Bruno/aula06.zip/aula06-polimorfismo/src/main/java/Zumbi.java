/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author SalvadorDonesta
 */
public class Zumbi extends Monstro {

    @Override
    public void assustar() {
        for (int i = 0; i < 3; i++){
            System.out.println("\nCérebroooo...");
        }
    }
    
    
}
